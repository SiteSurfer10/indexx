<!DOCTYPE html>

<html>
 
<head>
 
<title>How to put PHP in HTML - Simple Example</title>
 
</head>
 
<body>
 
<h1><?php echo "This message is from server side." ?></h1>
 
</body>
 
</html>
